package question1;
	import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.ResultSetMetaData;
	import java.sql.Statement;

	public class Artifacts {

	  public static void main(String[] argv) throws Exception {
	    Class.forName("com.mysql.jdbc.Driver");
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lifecycle_pets_db",
	        "root", "JaiMataDi@91");

	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery("DESCRIBE artifacts");
	    ResultSetMetaData md = rs.getMetaData();
	    int col = md.getColumnCount();
	    for (int i = 1; i <= col; i++) {
	      String col_name = md.getColumnName(i);
	      System.out.println(col_name);
	    }
	
	    DatabaseMetaData dbm = con.getMetaData();
	    ResultSet rs1 = dbm.getColumns(null, "%", "artifacts", "%");
	    while (rs1.next()) {
	      String col_name = rs1.getString("COLUMN_NAME");
	      String data_type = rs1.getString("TYPE_NAME");
	      int data_size = rs1.getInt("COLUMN_SIZE");
	      int nullable = rs1.getInt("NULLABLE");
	      System.out.println(col_name + " " + data_type + "(" + data_size + ")");
	      if (nullable == 1) {
	        System.out.println("YES");
	      } else {
	        System.out.println("NO");
	      }
	    }
	  }
	}
	 
