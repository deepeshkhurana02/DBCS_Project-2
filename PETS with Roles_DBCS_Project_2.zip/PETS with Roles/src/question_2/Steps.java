package question_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Steps {
 
  public static void insertStep(String name, String desc) throws Exception {
	  try {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		  Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lifecycle_pets_db?useSSL=false", "root", "JaiMataDi@91");
		 
		  Statement stmt = conn.createStatement();
		
		  String insert = "INSERT INTO step (step_Name, step_Description) VALUES ('"+name+"', '"+desc+"');";
		  stmt.executeUpdate(insert);
		  
		  }
		  catch(Exception e) {
		  e.printStackTrace();
		  } 
  }
}